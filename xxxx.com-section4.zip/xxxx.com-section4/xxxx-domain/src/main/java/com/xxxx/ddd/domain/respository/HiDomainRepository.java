package com.xxxx.ddd.domain.respository;

public interface HiDomainRepository {

    String sayHi(String who);
}
