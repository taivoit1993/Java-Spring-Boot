package com.xxxx.ddd.domain.service;

public interface HiDomainService {

    /**
     * Say Hi
     *
     * @return
     */
    String sayHi(String who);
}
