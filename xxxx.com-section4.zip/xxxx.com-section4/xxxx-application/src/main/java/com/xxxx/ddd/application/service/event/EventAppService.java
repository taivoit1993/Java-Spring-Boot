package com.xxxx.ddd.application.service.event;

public interface EventAppService {
    String sayHi(String who);
}
